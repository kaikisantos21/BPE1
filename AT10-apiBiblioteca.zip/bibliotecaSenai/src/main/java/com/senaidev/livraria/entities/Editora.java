package com.senaidev.livraria.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Editora {
	@Id
	@GeneratedValue
	Long id_editora;
	@Column
	String nome_editora;
	@Column
	String cnpj;
	@Column
	String email;
	@Column
	String contato;

	// Construtores
	public Editora() {

	}

	public Editora(Long id_editora, String nome_editora, String cnpj, String email, String contato) {
		this.id_editora = id_editora;
		this.nome_editora = nome_editora;
		this.cnpj = cnpj;
		this.email = email;
		this.contato = contato;
	}

	// Getters e Setters
	public Long getId_editora() {
		return id_editora;
	}

	public void setId_editora(Long id_editora) {
		this.id_editora = id_editora;
	}

	public String getNome_editora() {
		return nome_editora;
	}

	public void setNome_editora(String nome_editora) {
		this.nome_editora = nome_editora;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContato() {
		return contato;
	}

	public void setContato(String contato) {
		this.contato = contato;
	}

}
