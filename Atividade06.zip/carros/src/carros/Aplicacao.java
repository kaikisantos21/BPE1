package carros;

public final class Aplicacao {

	public static void main(String[] args) {
		
		Carro.tracker = new carros();
		Carro.atributoModelo = new "Tracker";
		Carro.atributoMarca = "Chevrolet";
		Carro.atributoCor = "Preto";
		Carro.atributoAno=  2024;
		
		
		Carro.kadet = new carros();
		Carro.atributoModelo = new "Kadet";
		Carro.atributoMarca = new "Chevrolet";
		Carro.atributoCor = "cinza";
		Carro.atributosAno = 1980;
	}
	public void exibirInfo() {
		System.out.println();
}