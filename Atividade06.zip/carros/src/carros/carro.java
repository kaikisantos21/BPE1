package carros;

public class Carro {
	//atributos
	String AtrubutoModelo;
	String AtributoMarca;
	String AtributoCor;
	int AtributoAno; 
	
	 // construtores
	
	public Carro() {
		
	
		
		
		
		public Carro(String Modelo,String Marca,String Cor,Int Ano) {
			this.Modelo = Modelo;
			this.Marca = Marca;
			this.Cor = Cor;
			this.Ano = Ano;
		
		}
		
		// metodos 
		public void exibirInfo() {
			System.out.println();
		}
		
	}
		

		
	

}
